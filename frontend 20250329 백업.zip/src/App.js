import React, { useState } from 'react';
import { 
  Container, 
  Box, 
  Typography, 
  TextField, 
  IconButton,
  CircularProgress,
  Paper,
  Switch,
  FormControlLabel,
  Tabs,
  Tab,
  Link,
  List,
  ListItem
} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import { formatResponse, responseStyles } from './utils/responseFormatter';
import { sendQueryToN8n, getTestResponse } from './services/apiService';

// 탭 패널 컴포넌트
function TabPanel({ children, value, index }) {
  return (
    <Box
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      sx={{ pt: 2 }}
    >
      {value === index && children}
    </Box>
  );
}

// 결과 패널 컴포넌트
function ResultPanel({ result }) {
  const [activeTab, setActiveTab] = useState(0);

  return (
    <Paper sx={{ p: 2, mb: 2 }}>
      <Typography 
        variant="subtitle1" 
        sx={{ 
          mb: 1, 
          fontWeight: 'bold',
          fontSize: '1.1rem',
          color: 'text.primary' 
        }}
      >
        {result.query}
      </Typography>
      
      {/* 탭 네비게이션 */}
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs 
          value={activeTab} 
          onChange={(e, newValue) => setActiveTab(newValue)}
          variant="fullWidth"
        >
          <Tab label="답변" />
          <Tab label={`출처 (${result.links?.length || 0})`} />
        </Tabs>
      </Box>

      {/* 답변 탭 패널 */}
      <TabPanel value={activeTab} index={0}>
        <Typography 
          variant="body1" 
          sx={{ 
            whiteSpace: 'pre-wrap',
            backgroundColor: '#f5f5f5',
            padding: 2,
            borderRadius: 1,
            color: '#333'
          }}
        >
          {result.text}
        </Typography>
      </TabPanel>

      {/* 출처 탭 패널 */}
      <TabPanel value={activeTab} index={1}>
        <List>
          {result.links.map((link, index) => (
            <ListItem 
              key={index} 
              component="a"
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              sx={{ 
                flexDirection: 'row', 
                alignItems: 'center',
                backgroundColor: '#f5f5f5',
                mb: 1,
                borderRadius: 1,
                padding: 2,
                textDecoration: 'none',
                color: 'inherit',
                '&:hover': {
                  backgroundColor: '#e0e0e0',
                }
              }}
            >
              <Box sx={{ 
                display: 'flex', 
                alignItems: 'center',
                gap: 2,
                width: '100%'
              }}>
                <img 
                  src={`https://www.google.com/s2/favicons?domain=${new URL(link.url).hostname}&sz=32`}
                  alt=""
                  style={{
                    width: 16,
                    height: 16,
                    objectFit: 'contain'
                  }}
                />
                <Box sx={{ flexGrow: 1 }}>
                  <Typography 
                    variant="subtitle1" 
                    sx={{ 
                      fontWeight: 'bold',
                      color: '#1976d2',
                      mb: 0.5
                    }}
                  >
                    {link.title}
                  </Typography>
                  <Typography 
                    variant="body2" 
                    sx={{ 
                      color: '#666',
                      wordBreak: 'break-all'
                    }}
                  >
                    {link.url}
                  </Typography>
                </Box>
              </Box>
            </ListItem>
          ))}
        </List>
      </TabPanel>
    </Paper>
  );
}

function App() {
  // 상태 관리
  const [query, setQuery] = useState(''); // 검색어 입력 상태
  const [loading, setLoading] = useState(false); // 로딩 상태
  const [results, setResults] = useState([]); // 검색 결과 목록
  const [isTestMode, setIsTestMode] = useState(true); // 테스트 모드 상태
  const [error, setError] = useState(null); // 에러 상태

  // 검색 처리 함수
  const handleSearch = async () => {
    if (!query.trim()) return;

    setLoading(true);
    setError(null);
    
    try {
      // 테스트 모드에 따라 다른 응답 처리
      const response = isTestMode 
        ? getTestResponse(query)
        : await sendQueryToN8n(query);
        
      const formattedResponse = formatResponse(response);
      
      setResults(prev => [{
        query,
        text: formattedResponse.text,
        links: formattedResponse.links
      }, ...prev]);
    } catch (error) {
      console.error('검색 중 오류가 발생했습니다:', error);
      setError('검색 중 오류가 발생했습니다. 다시 시도해주세요.');
    } finally {
      setLoading(false);
      setQuery(''); // 입력창 초기화
    }
  };

  return (
    <Container maxWidth="md">
      {/* 테스트 모드 토글 스위치 */}
      <Box sx={{ position: 'absolute', top: 16, left: 16 }}>
        <FormControlLabel
          control={
            <Switch
              checked={isTestMode}
              onChange={(e) => setIsTestMode(e.target.checked)}
              size="small"
            />
          }
          label={
            <Typography variant="caption" sx={{ color: isTestMode ? 'primary.main' : 'text.secondary' }}>
              테스트 모드 {isTestMode ? 'ON' : 'OFF'}
            </Typography>
          }
        />
      </Box>

      <Box sx={{ my: 4, textAlign: 'center' }}>
        {/* 제목 */}
        <Typography variant="h3" component="h1" gutterBottom>
          무엇을 알고 싶으세요?
        </Typography>
        
        {/* 검색 입력 영역 */}
        <Box sx={{ display: 'flex', gap: 1, mb: 4 }}>
          <TextField
            fullWidth
            variant="outlined"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="무엇이든 질문하기..."
            disabled={loading}
            onKeyPress={(e) => {
              if (e.key === 'Enter') {
                handleSearch();
              }
            }}
          />
          <IconButton 
            color="primary" 
            onClick={handleSearch}
            disabled={loading || !query.trim()}
          >
            {loading ? <CircularProgress size={24} /> : <SendIcon />}
          </IconButton>
        </Box>

        {/* 검색 결과 표시 영역 */}
        <Box sx={{ mt: 4 }}>
          {results.map((result, index) => (
            <ResultPanel key={index} result={result} />
          ))}
        </Box>
      </Box>
    </Container>
  );
}

export default App; 