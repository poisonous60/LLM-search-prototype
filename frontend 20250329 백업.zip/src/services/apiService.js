import axios from 'axios';
import { testResponse } from '../data/testData';

// 백엔드 API URL 환경 변수
const BACKEND_API_URL = process.env.REACT_APP_BACKEND_API_URL || 'http://localhost:8000';

/**
 * 백엔드 API로 POST 요청을 보내는 함수
 * @param {string} query - 사용자 입력 검색어
 * @returns {Promise} API 응답
 */
export const sendQueryToBackend = async (query) => {
  if (!query) {
    throw new Error('검색어를 입력해주세요.');
  }

  try {
    const response = await axios.post(`${BACKEND_API_URL}/api/v1/webhook`, {
      query: {
        userInput: query
      }
    }, {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    });

    // API 응답 형식 검증
    if (!response.data.success) {
      throw new Error(response.data.error || '요청 처리 중 오류가 발생했습니다.');
    }

    return response.data.data;
  } catch (error) {
    console.error('API 요청 실패:', error);
    if (error.response) {
      // 서버에서 반환된 에러 메시지 사용
      throw new Error(error.response.data.error || '서버 오류가 발생했습니다.');
    } else if (error.request) {
      // 요청은 보내졌지만 응답을 받지 못한 경우
      throw new Error('서버와 통신할 수 없습니다. 서버가 실행 중인지 확인해주세요.');
    } else {
      // 요청 설정 중 발생한 에러
      throw new Error('요청을 보내는 중 오류가 발생했습니다.');
    }
  }
};

/**
 * 테스트 모드에서 사용할 더미 응답 생성 함수
 * @param {string} query - 사용자 입력 검색어
 * @returns {Object} 테스트 응답
 */
export const getTestResponse = (query) => {
  return {
    success: true,
    data: testResponse
  };
}; 