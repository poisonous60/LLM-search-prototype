export const testResponse = [
  {
    link: [
      {
        title: '구운계란 검색결과',
        url: 'https://m.gmarket.co.kr/n/search?keyword=%EA%B5%AC%EC%9A%B4%EA%B3%84%EB%9E%80'
      },
      {
        title: '구운계란 : 다나와 통합검색',
        url: 'https://search.danawa.com/dsearch.php?query=%EA%B5%AC%EC%9A%B4%EA%B3%84%EB%9E%80'
      },
      {
        title: "'맥반석구운계란' 최저가 검색, 최저가 9710원",
        url: 'http://m.coocha.co.kr/search/search.do?keyword=%EB%A7%A5%EB%B0%98%EC%84%9D%EA%B5%AC%EC%9A%B4%EA%B3%84%EB%9E%80'
      },
      {
        title: '이마트 웰굿 맥반석 숙성 구운 계란 중란 30구',
        url: 'https://prod.danawa.com/info/?pcode=32188067'
      },
      {
        title: '구운계란 1판(30구) 중란',
        url: 'https://eggfac.com/product/%EB%A7%A5%EB%B0%98%EC%8B%9D%EA%B5%AC%EC%9A%B4%EA%B3%84%EB%9E%80-1%ED%8C%9030%EA%B5%AC-%EC%A4%91%EB%9E%80/65/'
      },
      {
        title: '구운계란 30구/60구/90구 - 오아시스마켓',
        url: 'https://m.oasis.co.kr/product/detail/14752'
      },
      {
        title: '계란 한판 최저 가격은 4980원, 오렌지는 개당 867원 - 식품저널',
        url: 'https://www.foodnews.co.kr/news/articleView.html?idxno=107354'
      },
      {
        title: '구운계란 - 검색결과 - 쇼핑하우',
        url: 'https://m.shoppinghow.kakao.com/m/search/q/%EA%B5%AC%EC%9A%B4%20%EA%B3%84%EB%9E%80'
      }
    ],
    response: {
      text: '구운 계란의 가격은 다양하게 형성되며, 일반적으로 판매되는 가격대는 1개당 100원에서 300원 정도입니다. 맥반석 구운 계란의 경우 30구 기준으로 약 9,710원에서 15,000원 정도의 가격대를 형성하고 있습니다. 구매처나 판매처에 따라 조금씩 다를 수 있습니다. 추가적인 정보가 필요하시면 말씀해 주세요.'
    }
  }
]; 